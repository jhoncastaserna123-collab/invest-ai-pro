# INVEST AI PRO — Complete Starter v1.0

Consolidated modular starter for the agreed informational/educational financial platform.
This is a development foundation, **not a production-ready or deployed application**.

## Included
- FastAPI backend and versioned API
- Local identity module: registration, Argon2 password hashing, JWT login
- Email verification intentionally represented as a pending workflow; no real email provider wired
- Demo global markets data clearly marked as not live
- Proposed subscription plans; no real charges
- Owner/admin overview endpoint with explicit demo status
- Business setup assistant checklist (guidance only)
- AI agent orchestration interfaces/stubs; no autonomous production actions
- Security and deployment checklist
- Responsive web starter UI
- Initial automated API tests

## Requirements
- Python 3.11+
- Node.js is not required for the static starter frontend
- Docker optional

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Replace JWT_SECRET with a long random secret before any non-local use.
uvicorn app.main:app --reload
```
Backend docs: http://127.0.0.1:8000/docs
Frontend: open `frontend/index.html` in a browser.

## Tests
```bash
pip install -r requirements-dev.txt
pytest
```

## API endpoints
- `GET /health`
- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `GET /api/v1/markets`
- `GET /api/v1/subscriptions/plans`
- `GET /api/v1/business/setup`
- `GET /api/v1/owner/overview`
- `GET /api/v1/agents`

## Production blockers — must be completed before launch
1. Implement real email verification, password reset, MFA/passkeys, session revocation and account recovery.
2. Move from SQLite to managed PostgreSQL; add Alembic migrations, backups and tested restores.
3. Add distributed rate limits, abuse detection, WAF, TLS, secure headers, secrets manager and key rotation.
4. Add persistent immutable audit logs and role-based/attribute-based access control.
5. Integrate licensed market-data providers and honor exchange-specific delay/redistribution terms.
6. Integrate an approved LLM provider with RAG, permission-scoped tools, evaluations and human approval gates.
7. Integrate subscription payments only after the company, authorized representative, provider onboarding and bank settlement account are ready. Use signed webhooks and idempotency. Never store PAN/CVV/PIN/bank credentials.
8. Complete privacy notices, terms, age eligibility, tax and legal reviews for each market.
9. Build native mobile clients, accessibility, localization, monitoring and incident response.
10. Run security review, penetration testing by authorized professionals, load tests, disaster recovery exercises and app-store compliance.

## Safety and product boundary
This product is designed for financial information and education. It does not custody investment funds, accept investment deposits, execute trades, or guarantee returns. Any portfolio feature must remain a watchlist/simulator unless separately reviewed and legally authorized. Demo market data must never be represented as live.


## Interfaz móvil/web de demostración
La página `frontend/index.html` incluye navegación local entre módulos, gráfico ilustrativo y contenidos educativos de ejemplo. No se conecta automáticamente al backend ni a proveedores externos. Los datos son ficticios y no hay pagos ni operaciones financieras.
