from fastapi import APIRouter
from app.api.routes import auth, markets, subscriptions, business, owner, agents

api_router = APIRouter()
api_router.include_router(auth.router, prefix="/auth", tags=["identity"])
api_router.include_router(markets.router, prefix="/markets", tags=["global markets"])
api_router.include_router(subscriptions.router, prefix="/subscriptions", tags=["subscriptions"])
api_router.include_router(business.router, prefix="/business", tags=["business setup"])
api_router.include_router(owner.router, prefix="/owner", tags=["owner control"])
api_router.include_router(agents.router, prefix="/agents", tags=["AI agents"])
