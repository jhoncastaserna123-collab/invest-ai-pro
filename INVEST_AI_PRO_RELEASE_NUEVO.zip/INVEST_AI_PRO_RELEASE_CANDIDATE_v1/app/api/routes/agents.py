from fastapi import APIRouter
router = APIRouter()

@router.get("")
def agents():
    return {
        "mode": "SAFE_STUBS_NO_AUTONOMOUS_PRODUCTION_ACTIONS",
        "agents": [
            {"name": "MASTER CONTROL", "status": "SCAFFOLD"},
            {"name": "INVEST AI AUTONOMOUS ASSISTANT", "status": "SCAFFOLD"},
            {"name": "DEV AGENT", "status": "SCAFFOLD"},
            {"name": "SYSTEM MONITOR AI", "status": "SCAFFOLD"},
            {"name": "SECURITY AI", "status": "SCAFFOLD"},
            {"name": "BUSINESS ASSISTANT", "status": "SCAFFOLD"},
        ],
        "policy": "Critical changes require authorized human approval.",
    }
