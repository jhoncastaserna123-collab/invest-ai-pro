from fastapi import APIRouter
router = APIRouter()

@router.get("/setup")
def business_setup():
    return {
        "company_jurisdiction_target": "Colombia",
        "status": "RESERVED_PENDING_LEGAL_ENTITY",
        "items": [
            {"key": "legal_entity", "label": "Constitución y registro de la empresa", "status": "PENDING"},
            {"key": "tax_registration", "label": "NIT y RUT", "status": "PENDING"},
            {"key": "business_bank_account", "label": "Cuenta bancaria empresarial", "status": "PENDING"},
            {"key": "payment_provider", "label": "Pasarela de pagos y verificación", "status": "PENDING"},
            {"key": "settlement_test", "label": "Prueba de liquidación de suscripciones", "status": "PENDING"},
        ],
        "assistant_scope": [
            "Explicar requisitos y preparar listas de documentos",
            "Comparar proveedores y comisiones documentadas",
            "Guiar configuración en portales oficiales",
            "Nunca solicitar ni almacenar PIN, CVV, contraseña bancaria o número completo de tarjeta",
        ],
    }
