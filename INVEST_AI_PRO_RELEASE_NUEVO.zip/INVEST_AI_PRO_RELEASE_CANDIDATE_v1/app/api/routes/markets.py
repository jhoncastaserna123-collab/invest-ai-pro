from fastapi import APIRouter
router = APIRouter()

@router.get("")
def markets():
    return {
        "data_status": "DEMO_NOT_LIVE",
        "notice": "Datos ficticios de demostración; no son cotizaciones actuales.",
        "items": [
            {"symbol": "DEMO-INDEX", "name": "Índice demostrativo", "price": 100.0, "change_pct": 0.45},
            {"symbol": "DEMO-ASSET", "name": "Activo demostrativo", "price": 25.0, "change_pct": -0.20},
        ],
    }
