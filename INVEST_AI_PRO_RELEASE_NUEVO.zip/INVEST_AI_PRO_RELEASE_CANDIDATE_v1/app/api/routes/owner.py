from fastapi import APIRouter
router = APIRouter()

@router.get("/overview")
def owner_overview():
    return {
        "environment": "DEVELOPMENT",
        "production_deployment": False,
        "market_data": "DEMO_ONLY",
        "payments": "NOT_CONNECTED",
        "business_setup": "PENDING",
        "security_review": "NOT_COMPLETED",
        "modules": [
            "GLOBAL MARKETS", "AI CORE", "OWNER CONTROL CENTER",
            "BUSINESS ASSISTANT", "SECURITY CORE", "SUBSCRIPTIONS SANDBOX"
        ],
    }
