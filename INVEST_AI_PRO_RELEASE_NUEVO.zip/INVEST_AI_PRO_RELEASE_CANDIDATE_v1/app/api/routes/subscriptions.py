from fastapi import APIRouter
router = APIRouter()

@router.get("/plans")
def plans():
    return {
        "currency": "USD",
        "prices_are_proposals": True,
        "payments_mode": "NOT_CONNECTED",
        "items": [
            {"code": "FREE", "monthly_price": 0.00},
            {"code": "PRO", "monthly_price": 19.99},
            {"code": "PREMIUM", "monthly_price": 39.99},
            {"code": "ELITE", "monthly_price": 79.99},
        ],
    }

@router.get("/status")
def subscription_status():
    return {"status": "SANDBOX_NOT_CONNECTED", "real_billing_enabled": False}
