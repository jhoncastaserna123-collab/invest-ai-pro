from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "sqlite:///./invest_ai_pro_dev.db"
    jwt_secret: str = "CHANGE_THIS_FOR_LOCAL_TESTS_ONLY"
    jwt_issuer: str = "invest-ai-pro"
    jwt_expire_minutes: int = 20
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
