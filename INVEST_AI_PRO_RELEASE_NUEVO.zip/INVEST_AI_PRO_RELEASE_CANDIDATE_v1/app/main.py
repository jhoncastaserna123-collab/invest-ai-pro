from fastapi import FastAPI
from app.core.config import settings
from app.db import Base, engine
from app import models  # noqa: F401
from app.api.router import api_router

Base.metadata.create_all(bind=engine)  # Development convenience only; use migrations in production.

app = FastAPI(
    title="INVEST AI PRO",
    version="1.0.0",
    description="Development starter for an informational and educational market platform.",
)
app.include_router(api_router, prefix="/api/v1")

@app.get("/health", tags=["health"])
def health():
    return {"status": "ok", "environment": settings.app_env, "version": "1.0.0"}
