# Architecture

Initial modular monolith to reduce time-to-first-test and operational complexity.
Separate services only when measured scale and team capacity justify them.

- API: FastAPI, versioned routes
- Development database: SQLite only
- Production target: managed PostgreSQL plus migrations
- Frontend: static responsive preview; production web client still to build
- Mobile: Flutter client planned, not included in this starter
- Market data: licensed provider adapter required
- AI: provider adapter + retrieval + permission-scoped tools required
- Payments: hosted checkout/provider integration required
- Infrastructure: start with one region, add recovery region, then regional expansion based on demand

Never treat demo fixtures as live market prices or proposed subscription prices as approved commercial offers.
