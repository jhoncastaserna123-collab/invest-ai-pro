# INVEST AI PRO — Final Scope Freeze

This is the closed product scope. No additional modules are planned in this release.

Included product areas:
- Global Markets (licensed provider integration required; demo fixtures are not live)
- INVEST AI CORE (analysis interfaces; real model/provider integration and evaluation required)
- Owner Control Center and the previously specified AI agents
- Identity and account management
- Security, audit, backup and recovery controls
- Subscription plans and sandbox payment workflow
- Business Assistant and reserved company/bank/payment setup section
- Web client foundation and mobile-client implementation plan
- Localization and accessibility requirements

Financial boundary:
- Informational and educational use only.
- No custody of investment funds, investment deposits, trade execution, or guaranteed returns.
- Subscription payments are commercial payments for platform access only.
- Never collect card PAN/CVV/PIN or online banking credentials in the app's own database.
