# Operations Notes

## Local development
Use the root README instructions. The local database and demo market feed are for development only.

## Environment separation
Maintain separate development, staging and production projects, credentials, databases and payment provider environments.
Never copy production personal data into development.

## Payments
Keep payment state derived from verified provider webhooks and reconciliation, not browser redirects.
Use idempotency keys. Keep bank settlement account setup outside this application until the legal entity and authorized representative complete provider onboarding.

## Autonomous agents
Agents may inspect, summarize, draft and test within scoped permissions. Privileged changes, money movement, production deployment, account deletion and permission changes require explicit human approval. Do not give agents bank credentials or unrestricted production access.
