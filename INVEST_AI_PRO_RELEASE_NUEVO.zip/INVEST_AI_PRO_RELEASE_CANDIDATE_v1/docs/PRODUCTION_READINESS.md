# Production Readiness Gate

A release is blocked until every applicable item is verified and signed off.

## Identity
- [ ] Email verification with expiring, single-use tokens
- [ ] Password reset with single-use tokens
- [ ] MFA/passkeys and recovery codes
- [ ] Session inventory, revocation, refresh-token rotation
- [ ] Rate limits, progressive throttling and abuse monitoring
- [ ] Generic auth errors and security event audit trail

## Platform
- [ ] PostgreSQL and schema migrations
- [ ] Secret manager and rotation process
- [ ] TLS, secure headers, WAF, DDoS controls
- [ ] RBAC/ABAC and admin MFA
- [ ] Encrypted backups, restore tests, RPO/RTO
- [ ] Centralized logs, metrics, alerting and incident runbooks

## AI
- [ ] Provider and data-processing terms reviewed
- [ ] Tool permissions scoped per role and user
- [ ] Prompt injection defenses and untrusted-data boundaries
- [ ] Human approval for privileged/irreversible actions
- [ ] Evaluation suite, hallucination handling and safety tests

## Markets
- [ ] Data vendor contracts and exchange redistribution rights
- [ ] Correct real-time/delayed labels per instrument
- [ ] Market holidays, sessions, currency and timestamp handling
- [ ] Monitoring for stale/missing/outlier data

## Payments
- [ ] Legal entity and authorized representative onboarded
- [ ] Payment provider approved for countries/currencies
- [ ] Business settlement account verified by provider
- [ ] Signed webhook verification and idempotency
- [ ] Refund/dispute/tax/invoice workflows tested
- [ ] No storage of card security codes or full card credentials

## Legal and release
- [ ] Privacy notice, terms, retention and user rights
- [ ] Age and jurisdiction eligibility review
- [ ] Accessibility, localization and app-store review
- [ ] Dependency scanning, SAST/DAST and authorized penetration test
- [ ] Load, failover and disaster recovery exercises
- [ ] Human release approval and rollback plan
