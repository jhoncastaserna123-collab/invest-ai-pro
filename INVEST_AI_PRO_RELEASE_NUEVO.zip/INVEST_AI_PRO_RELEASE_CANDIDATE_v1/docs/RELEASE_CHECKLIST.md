# Release Candidate Checklist

This checklist is intentionally a gate, not a claim that tasks have been completed.

## Build and test
- [ ] Install dependencies in a clean environment
- [ ] Run `pytest`
- [ ] Run static analysis, dependency and secret scanning
- [ ] Build container image and scan it
- [ ] Verify OpenAPI contracts and error handling

## Security
- [ ] Replace development JWT secret with managed secret
- [ ] Implement email verification and password reset
- [ ] Implement MFA/passkeys, refresh rotation and session revocation
- [ ] Add rate limits and anti-abuse controls
- [ ] Add admin RBAC/ABAC, immutable audit logs and alerting
- [ ] Complete authorized independent security review

## Integrations
- [ ] Contract licensed market data and test staleness labels
- [ ] Connect AI provider with permission-scoped tools and evaluation suite
- [ ] Complete payment provider onboarding after legal entity and settlement account exist
- [ ] Verify signed webhooks, idempotency, refunds and reconciliation

## Operations
- [ ] Deploy staging and production separately
- [ ] Configure TLS, WAF, backups, monitoring and incident response
- [ ] Test restore, failover, load and rollback
- [ ] Complete legal, privacy, tax, age and app-store reviews
- [ ] Obtain authorized human release approval
