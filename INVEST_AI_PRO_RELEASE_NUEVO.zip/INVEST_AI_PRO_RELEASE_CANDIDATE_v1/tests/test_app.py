from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").status_code == 200

def test_markets_explicitly_demo():
    r = client.get("/api/v1/markets")
    assert r.status_code == 200
    assert r.json()["data_status"] == "DEMO_NOT_LIVE"

def test_plans_not_real_billing():
    r = client.get("/api/v1/subscriptions/plans")
    assert r.status_code == 200
    assert r.json()["payments_mode"] == "NOT_CONNECTED"

def test_business_setup_reserved():
    r = client.get("/api/v1/business/setup")
    assert r.status_code == 200
    assert r.json()["status"] == "RESERVED_PENDING_LEGAL_ENTITY"

def test_agents_are_scaffold_only():
    r = client.get("/api/v1/agents")
    assert r.status_code == 200
    assert "NO_AUTONOMOUS" in r.json()["mode"]
